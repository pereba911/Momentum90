import { createClient } from "@supabase/supabase-js";

const SUPABASE_URL = "https://xhxvbqawahwqccaooram.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhoeHZicWF3YWh3cWNjYW9vcmFtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODMwMTEzMzUsImV4cCI6MjA5ODU4NzMzNX0.2GnT72AdGr3Kvq1sPub9Xevj1K6p9ywq2U8Fwp3OQKg";
export const API_BASE = "https://xhxvbqawahwqccaooram.supabase.co/functions/v1/make-server-da3143e6";
export const ADMIN_EMAIL = "octaface@gmail.com";
export const PRICE_USD = "$14.99";
export const STRIPE_PAYMENT_LINK = ""; // Set your Stripe payment link here

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: { persistSession: true, autoRefreshToken: true, storageKey: "m90_session" },
});

export interface UserProfile {
  id: string; email: string;
  role: "admin" | "user";
  subscription_status: "active" | "trial" | "expired";
  subscription_expires_at: string | null;
  stripe_customer_id?: string;
  created_at: string;
}

export interface UserSettings {
  currency: string;
  darkMode: boolean;
  language: "es" | "en";
  fundLabels: { emergency: string; investment: string; custom: string };
  stripeUrl: string;
}

export const DEFAULT_SETTINGS: UserSettings = {
  currency: "MXN",
  darkMode: true,
  language: "es",
  fundLabels: { emergency: "Fondo de Emergencia", investment: "Capital de Inversión", custom: "Fondo Personal" },
  stripeUrl: STRIPE_PAYMENT_LINK,
};

// ─── API helpers ──────────────────────────────────────────────────────────────
async function apiCall(token: string, method: string, path: string, body?: unknown) {
  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) throw new Error(`API ${method} ${path} → ${res.status}`);
  return res.json();
}

export const api = {
  getProfile: (t: string) => apiCall(t, "GET", "/profile"),
  getData: (t: string) => apiCall(t, "GET", "/data"),
  saveData: (t: string, data: unknown) => apiCall(t, "POST", "/data", { data }),
  getSettings: (t: string) => apiCall(t, "GET", "/settings"),
  saveSettings: (t: string, settings: UserSettings) => apiCall(t, "POST", "/settings", { settings }),
  getUsers: (t: string) => apiCall(t, "GET", "/users"),
  updateUser: (t: string, userId: string, updates: Partial<UserProfile>) => apiCall(t, "PUT", `/profile/${userId}`, updates),
};

export function getDaysLeft(profile: UserProfile | null): number {
  if (!profile || profile.role === "admin" || profile.subscription_status === "active") return Infinity;
  if (!profile.subscription_expires_at) return 0;
  const diff = new Date(profile.subscription_expires_at).getTime() - Date.now();
  return Math.max(0, Math.ceil(diff / 86400000));
}

export function canAccess(profile: UserProfile | null): boolean {
  if (!profile) return false;
  if (profile.role === "admin") return true;
  if (profile.subscription_status === "active") return true;
  if (profile.subscription_status === "trial" && getDaysLeft(profile) > 0) return true;
  return false;
}
