import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "jsr:@supabase/supabase-js@2.49.8";
import * as kv from "./kv_store.tsx";

const app = new Hono();
const ADMIN_EMAIL = "octaface@gmail.com";

app.use("*", logger(console.log));
app.use("/*", cors({
  origin: "*",
  allowHeaders: ["Content-Type", "Authorization"],
  allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  exposeHeaders: ["Content-Length"],
  maxAge: 600,
}));

// ── Auth helper ──────────────────────────────────────────────────────────────
async function getUser(authHeader: string | undefined) {
  if (!authHeader?.startsWith("Bearer ")) return null;
  const token = authHeader.slice(7);
  const { data: { user }, error } = await createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_ANON_KEY")!,
  ).auth.getUser(token);
  if (error || !user) return null;
  return user;
}

function makeDefaultProfile(user: any) {
  const isAdmin = user.email === ADMIN_EMAIL;
  return {
    id: user.id,
    email: user.email,
    role: isAdmin ? "admin" : "user",
    subscription_status: isAdmin ? "active" : "trial",
    subscription_expires_at: isAdmin
      ? null
      : new Date(Date.now() + 14 * 86400000).toISOString(),
    created_at: new Date().toISOString(),
  };
}

// ── Health ────────────────────────────────────────────────────────────────────
app.get("/make-server-da3143e6/health", (c) => c.json({ status: "ok" }));

// ── Profile ───────────────────────────────────────────────────────────────────
app.get("/make-server-da3143e6/profile", async (c) => {
  const user = await getUser(c.req.header("Authorization"));
  if (!user) return c.json({ error: "Unauthorized" }, 401);

  let profile = await kv.get(`profile_${user.id}`);
  if (!profile) {
    profile = makeDefaultProfile(user);
    await kv.set(`profile_${user.id}`, profile);
    // Add to user index
    const index: string[] = (await kv.get("user_index")) ?? [];
    if (!index.includes(user.id)) {
      index.push(user.id);
      await kv.set("user_index", index);
    }
  }
  // Always enforce admin email
  if (user.email === ADMIN_EMAIL && profile.role !== "admin") {
    profile = { ...profile, role: "admin", subscription_status: "active" };
    await kv.set(`profile_${user.id}`, profile);
  }
  return c.json({ profile });
});

// Admin: update a user profile
app.put("/make-server-da3143e6/profile/:userId", async (c) => {
  const user = await getUser(c.req.header("Authorization"));
  if (!user) return c.json({ error: "Unauthorized" }, 401);
  const myProfile = await kv.get(`profile_${user.id}`);
  if (myProfile?.role !== "admin") return c.json({ error: "Forbidden" }, 403);

  const userId = c.req.param("userId");
  const updates = await c.req.json();
  const profile = await kv.get(`profile_${userId}`);
  if (!profile) return c.json({ error: "Not found" }, 404);
  const updated = { ...profile, ...updates };
  await kv.set(`profile_${userId}`, updated);
  return c.json({ profile: updated });
});

// ── App Data ──────────────────────────────────────────────────────────────────
app.get("/make-server-da3143e6/data", async (c) => {
  const user = await getUser(c.req.header("Authorization"));
  if (!user) return c.json({ error: "Unauthorized" }, 401);
  const data = await kv.get(`data_${user.id}`);
  return c.json({ data: data ?? null });
});

app.post("/make-server-da3143e6/data", async (c) => {
  const user = await getUser(c.req.header("Authorization"));
  if (!user) return c.json({ error: "Unauthorized" }, 401);
  const { data } = await c.req.json();
  await kv.set(`data_${user.id}`, data);
  return c.json({ success: true });
});

// ── Settings ──────────────────────────────────────────────────────────────────
app.get("/make-server-da3143e6/settings", async (c) => {
  const user = await getUser(c.req.header("Authorization"));
  if (!user) return c.json({ error: "Unauthorized" }, 401);
  const settings = await kv.get(`settings_${user.id}`);
  return c.json({ settings: settings ?? null });
});

app.post("/make-server-da3143e6/settings", async (c) => {
  const user = await getUser(c.req.header("Authorization"));
  if (!user) return c.json({ error: "Unauthorized" }, 401);
  const { settings } = await c.req.json();
  await kv.set(`settings_${user.id}`, settings);
  return c.json({ success: true });
});

// ── Admin: users list ─────────────────────────────────────────────────────────
app.get("/make-server-da3143e6/users", async (c) => {
  const user = await getUser(c.req.header("Authorization"));
  if (!user) return c.json({ error: "Unauthorized" }, 401);
  const myProfile = await kv.get(`profile_${user.id}`);
  if (myProfile?.role !== "admin") return c.json({ error: "Forbidden" }, 403);
  const index: string[] = (await kv.get("user_index")) ?? [];
  const profiles = await Promise.all(index.map((id) => kv.get(`profile_${id}`)));
  return c.json({ users: profiles.filter(Boolean) });
});

Deno.serve(app.fetch);
